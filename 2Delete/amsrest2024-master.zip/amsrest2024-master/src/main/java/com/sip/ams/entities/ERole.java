package com.sip.ams.entities;

public enum ERole {
	SUPER_ADMIN, ADMIN, USER
}