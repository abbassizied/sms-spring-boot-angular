package io.github.abbassizied.sms;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmsRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
