export const environment = {
  production: false,
  baseUrl : 'http://127.0.0.1:8080/',
  urlUploadImage:'http://127.0.0.1:8080/uploads'
};
