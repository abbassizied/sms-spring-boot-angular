export const environment = {
  production: true,
  baseUrl : 'http://sip-academy.com/api/', // autre lien prod
  urlUploadImage:'http://127.0.0.1:8080/uploads'
};
