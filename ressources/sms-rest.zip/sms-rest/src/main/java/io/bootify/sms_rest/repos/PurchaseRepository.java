package io.bootify.sms_rest.repos;

import io.bootify.sms_rest.domain.Purchase;
import io.bootify.sms_rest.domain.Supplier;
import org.springframework.data.jpa.repository.JpaRepository;


public interface PurchaseRepository extends JpaRepository<Purchase, Long> {

    Purchase findFirstBySupplier(Supplier supplier);

}
