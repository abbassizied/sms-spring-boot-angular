package io.bootify.sms_rest.repos;

import io.bootify.sms_rest.domain.Product;
import io.bootify.sms_rest.domain.Purchase;
import io.bootify.sms_rest.domain.PurchaseItem;
import org.springframework.data.jpa.repository.JpaRepository;


public interface PurchaseItemRepository extends JpaRepository<PurchaseItem, Long> {

    PurchaseItem findFirstByPurchase(Purchase purchase);

    PurchaseItem findFirstByProduct(Product product);

}
