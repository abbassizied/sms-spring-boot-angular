package io.bootify.sms_rest.repos;

import io.bootify.sms_rest.domain.Order;
import io.bootify.sms_rest.domain.OrderItem;
import io.bootify.sms_rest.domain.Product;
import org.springframework.data.jpa.repository.JpaRepository;


public interface OrderItemRepository extends JpaRepository<OrderItem, Long> {

    OrderItem findFirstByOrder(Order order);

    OrderItem findFirstByProduct(Product product);

}
