package io.bootify.sms_rest.repos;

import io.bootify.sms_rest.domain.Customer;
import io.bootify.sms_rest.domain.Order;
import org.springframework.data.jpa.repository.JpaRepository;


public interface OrderRepository extends JpaRepository<Order, Long> {

    Order findFirstByCustomer(Customer customer);

}
