package io.bootify.sms_rest.model;

import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Size;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class ProductDTO {

    private Long id;

    @Size(max = 255)
    private String name;

    @Size(max = 255)
    private String mainImage;

    @Size(max = 255)
    private String description;

    private Double price;

    private Integer initialQuantity;

    private Integer quantity;

    @NotNull
    private Long supplier;

}
