package io.bootify.sms_rest.model;


public enum OrderStatus {

    IN_PROGRESS,
    CANCELED,
    COMPLETED

}
