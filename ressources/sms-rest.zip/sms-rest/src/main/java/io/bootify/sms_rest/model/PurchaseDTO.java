package io.bootify.sms_rest.model;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class PurchaseDTO {

    private Long id;

    @NotNull
    private Long supplier;

}
