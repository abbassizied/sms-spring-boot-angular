package io.bootify.sms_rest.service;

import io.bootify.sms_rest.domain.Purchase;
import io.bootify.sms_rest.domain.PurchaseItem;
import io.bootify.sms_rest.domain.Supplier;
import io.bootify.sms_rest.model.PurchaseDTO;
import io.bootify.sms_rest.repos.PurchaseItemRepository;
import io.bootify.sms_rest.repos.PurchaseRepository;
import io.bootify.sms_rest.repos.SupplierRepository;
import io.bootify.sms_rest.util.NotFoundException;
import io.bootify.sms_rest.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class PurchaseService {

    private final PurchaseRepository purchaseRepository;
    private final SupplierRepository supplierRepository;
    private final PurchaseItemRepository purchaseItemRepository;

    public PurchaseService(final PurchaseRepository purchaseRepository,
            final SupplierRepository supplierRepository,
            final PurchaseItemRepository purchaseItemRepository) {
        this.purchaseRepository = purchaseRepository;
        this.supplierRepository = supplierRepository;
        this.purchaseItemRepository = purchaseItemRepository;
    }

    public List<PurchaseDTO> findAll() {
        final List<Purchase> purchases = purchaseRepository.findAll(Sort.by("id"));
        return purchases.stream()
                .map(purchase -> mapToDTO(purchase, new PurchaseDTO()))
                .toList();
    }

    public PurchaseDTO get(final Long id) {
        return purchaseRepository.findById(id)
                .map(purchase -> mapToDTO(purchase, new PurchaseDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final PurchaseDTO purchaseDTO) {
        final Purchase purchase = new Purchase();
        mapToEntity(purchaseDTO, purchase);
        return purchaseRepository.save(purchase).getId();
    }

    public void update(final Long id, final PurchaseDTO purchaseDTO) {
        final Purchase purchase = purchaseRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(purchaseDTO, purchase);
        purchaseRepository.save(purchase);
    }

    public void delete(final Long id) {
        purchaseRepository.deleteById(id);
    }

    private PurchaseDTO mapToDTO(final Purchase purchase, final PurchaseDTO purchaseDTO) {
        purchaseDTO.setId(purchase.getId());
        purchaseDTO.setSupplier(purchase.getSupplier() == null ? null : purchase.getSupplier().getId());
        return purchaseDTO;
    }

    private Purchase mapToEntity(final PurchaseDTO purchaseDTO, final Purchase purchase) {
        final Supplier supplier = purchaseDTO.getSupplier() == null ? null : supplierRepository.findById(purchaseDTO.getSupplier())
                .orElseThrow(() -> new NotFoundException("supplier not found"));
        purchase.setSupplier(supplier);
        return purchase;
    }

    public ReferencedWarning getReferencedWarning(final Long id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Purchase purchase = purchaseRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final PurchaseItem purchasePurchaseItem = purchaseItemRepository.findFirstByPurchase(purchase);
        if (purchasePurchaseItem != null) {
            referencedWarning.setKey("purchase.purchaseItem.purchase.referenced");
            referencedWarning.addParam(purchasePurchaseItem.getId());
            return referencedWarning;
        }
        return null;
    }

}
