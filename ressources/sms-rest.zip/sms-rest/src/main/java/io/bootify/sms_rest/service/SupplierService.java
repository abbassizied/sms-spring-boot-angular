package io.bootify.sms_rest.service;

import io.bootify.sms_rest.domain.Product;
import io.bootify.sms_rest.domain.Purchase;
import io.bootify.sms_rest.domain.Supplier;
import io.bootify.sms_rest.model.SupplierDTO;
import io.bootify.sms_rest.repos.ProductRepository;
import io.bootify.sms_rest.repos.PurchaseRepository;
import io.bootify.sms_rest.repos.SupplierRepository;
import io.bootify.sms_rest.util.NotFoundException;
import io.bootify.sms_rest.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class SupplierService {

    private final SupplierRepository supplierRepository;
    private final ProductRepository productRepository;
    private final PurchaseRepository purchaseRepository;

    public SupplierService(final SupplierRepository supplierRepository,
            final ProductRepository productRepository,
            final PurchaseRepository purchaseRepository) {
        this.supplierRepository = supplierRepository;
        this.productRepository = productRepository;
        this.purchaseRepository = purchaseRepository;
    }

    public List<SupplierDTO> findAll() {
        final List<Supplier> suppliers = supplierRepository.findAll(Sort.by("id"));
        return suppliers.stream()
                .map(supplier -> mapToDTO(supplier, new SupplierDTO()))
                .toList();
    }

    public SupplierDTO get(final Long id) {
        return supplierRepository.findById(id)
                .map(supplier -> mapToDTO(supplier, new SupplierDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final SupplierDTO supplierDTO) {
        final Supplier supplier = new Supplier();
        mapToEntity(supplierDTO, supplier);
        return supplierRepository.save(supplier).getId();
    }

    public void update(final Long id, final SupplierDTO supplierDTO) {
        final Supplier supplier = supplierRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(supplierDTO, supplier);
        supplierRepository.save(supplier);
    }

    public void delete(final Long id) {
        supplierRepository.deleteById(id);
    }

    private SupplierDTO mapToDTO(final Supplier supplier, final SupplierDTO supplierDTO) {
        supplierDTO.setId(supplier.getId());
        supplierDTO.setName(supplier.getName());
        supplierDTO.setLogoUrl(supplier.getLogoUrl());
        supplierDTO.setEmail(supplier.getEmail());
        supplierDTO.setPhone(supplier.getPhone());
        supplierDTO.setAddress(supplier.getAddress());
        return supplierDTO;
    }

    private Supplier mapToEntity(final SupplierDTO supplierDTO, final Supplier supplier) {
        supplier.setName(supplierDTO.getName());
        supplier.setLogoUrl(supplierDTO.getLogoUrl());
        supplier.setEmail(supplierDTO.getEmail());
        supplier.setPhone(supplierDTO.getPhone());
        supplier.setAddress(supplierDTO.getAddress());
        return supplier;
    }

    public ReferencedWarning getReferencedWarning(final Long id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Supplier supplier = supplierRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final Product supplierProduct = productRepository.findFirstBySupplier(supplier);
        if (supplierProduct != null) {
            referencedWarning.setKey("supplier.product.supplier.referenced");
            referencedWarning.addParam(supplierProduct.getId());
            return referencedWarning;
        }
        final Purchase supplierPurchase = purchaseRepository.findFirstBySupplier(supplier);
        if (supplierPurchase != null) {
            referencedWarning.setKey("supplier.purchase.supplier.referenced");
            referencedWarning.addParam(supplierPurchase.getId());
            return referencedWarning;
        }
        return null;
    }

}
