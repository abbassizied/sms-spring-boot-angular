package io.bootify.sms_rest.service;

import io.bootify.sms_rest.domain.Image;
import io.bootify.sms_rest.domain.OrderItem;
import io.bootify.sms_rest.domain.Product;
import io.bootify.sms_rest.domain.PurchaseItem;
import io.bootify.sms_rest.domain.Supplier;
import io.bootify.sms_rest.model.ProductDTO;
import io.bootify.sms_rest.repos.ImageRepository;
import io.bootify.sms_rest.repos.OrderItemRepository;
import io.bootify.sms_rest.repos.ProductRepository;
import io.bootify.sms_rest.repos.PurchaseItemRepository;
import io.bootify.sms_rest.repos.SupplierRepository;
import io.bootify.sms_rest.util.NotFoundException;
import io.bootify.sms_rest.util.ReferencedWarning;
import java.util.List;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;


@Service
public class ProductService {

    private final ProductRepository productRepository;
    private final SupplierRepository supplierRepository;
    private final ImageRepository imageRepository;
    private final OrderItemRepository orderItemRepository;
    private final PurchaseItemRepository purchaseItemRepository;

    public ProductService(final ProductRepository productRepository,
            final SupplierRepository supplierRepository, final ImageRepository imageRepository,
            final OrderItemRepository orderItemRepository,
            final PurchaseItemRepository purchaseItemRepository) {
        this.productRepository = productRepository;
        this.supplierRepository = supplierRepository;
        this.imageRepository = imageRepository;
        this.orderItemRepository = orderItemRepository;
        this.purchaseItemRepository = purchaseItemRepository;
    }

    public List<ProductDTO> findAll() {
        final List<Product> products = productRepository.findAll(Sort.by("id"));
        return products.stream()
                .map(product -> mapToDTO(product, new ProductDTO()))
                .toList();
    }

    public ProductDTO get(final Long id) {
        return productRepository.findById(id)
                .map(product -> mapToDTO(product, new ProductDTO()))
                .orElseThrow(NotFoundException::new);
    }

    public Long create(final ProductDTO productDTO) {
        final Product product = new Product();
        mapToEntity(productDTO, product);
        return productRepository.save(product).getId();
    }

    public void update(final Long id, final ProductDTO productDTO) {
        final Product product = productRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        mapToEntity(productDTO, product);
        productRepository.save(product);
    }

    public void delete(final Long id) {
        productRepository.deleteById(id);
    }

    private ProductDTO mapToDTO(final Product product, final ProductDTO productDTO) {
        productDTO.setId(product.getId());
        productDTO.setName(product.getName());
        productDTO.setMainImage(product.getMainImage());
        productDTO.setDescription(product.getDescription());
        productDTO.setPrice(product.getPrice());
        productDTO.setInitialQuantity(product.getInitialQuantity());
        productDTO.setQuantity(product.getQuantity());
        productDTO.setSupplier(product.getSupplier() == null ? null : product.getSupplier().getId());
        return productDTO;
    }

    private Product mapToEntity(final ProductDTO productDTO, final Product product) {
        product.setName(productDTO.getName());
        product.setMainImage(productDTO.getMainImage());
        product.setDescription(productDTO.getDescription());
        product.setPrice(productDTO.getPrice());
        product.setInitialQuantity(productDTO.getInitialQuantity());
        product.setQuantity(productDTO.getQuantity());
        final Supplier supplier = productDTO.getSupplier() == null ? null : supplierRepository.findById(productDTO.getSupplier())
                .orElseThrow(() -> new NotFoundException("supplier not found"));
        product.setSupplier(supplier);
        return product;
    }

    public ReferencedWarning getReferencedWarning(final Long id) {
        final ReferencedWarning referencedWarning = new ReferencedWarning();
        final Product product = productRepository.findById(id)
                .orElseThrow(NotFoundException::new);
        final Image productImage = imageRepository.findFirstByProduct(product);
        if (productImage != null) {
            referencedWarning.setKey("product.image.product.referenced");
            referencedWarning.addParam(productImage.getId());
            return referencedWarning;
        }
        final OrderItem productOrderItem = orderItemRepository.findFirstByProduct(product);
        if (productOrderItem != null) {
            referencedWarning.setKey("product.orderItem.product.referenced");
            referencedWarning.addParam(productOrderItem.getId());
            return referencedWarning;
        }
        final PurchaseItem productPurchaseItem = purchaseItemRepository.findFirstByProduct(product);
        if (productPurchaseItem != null) {
            referencedWarning.setKey("product.purchaseItem.product.referenced");
            referencedWarning.addParam(productPurchaseItem.getId());
            return referencedWarning;
        }
        return null;
    }

}
