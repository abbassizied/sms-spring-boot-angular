package io.bootify.sms_rest.repos;

import io.bootify.sms_rest.domain.Customer;
import org.springframework.data.jpa.repository.JpaRepository;


public interface CustomerRepository extends JpaRepository<Customer, Long> {
}
