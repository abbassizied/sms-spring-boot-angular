package io.bootify.sms_rest.model;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;


@Getter
@Setter
public class OrderDTO {

    private Long id;

    private OrderStatus orderStatus;

    @NotNull
    private Long customer;

}
