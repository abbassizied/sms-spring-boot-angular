package io.bootify.sms_rest.repos;

import io.bootify.sms_rest.domain.Image;
import io.bootify.sms_rest.domain.Product;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ImageRepository extends JpaRepository<Image, Long> {

    Image findFirstByProduct(Product product);

}
