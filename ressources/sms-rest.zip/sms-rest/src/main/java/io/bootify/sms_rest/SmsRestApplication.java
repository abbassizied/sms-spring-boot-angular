package io.bootify.sms_rest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;


@SpringBootApplication
public class SmsRestApplication {

    public static void main(final String[] args) {
        SpringApplication.run(SmsRestApplication.class, args);
    }

}
