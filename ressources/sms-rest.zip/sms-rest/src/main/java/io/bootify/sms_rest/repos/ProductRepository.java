package io.bootify.sms_rest.repos;

import io.bootify.sms_rest.domain.Product;
import io.bootify.sms_rest.domain.Supplier;
import org.springframework.data.jpa.repository.JpaRepository;


public interface ProductRepository extends JpaRepository<Product, Long> {

    Product findFirstBySupplier(Supplier supplier);

}
